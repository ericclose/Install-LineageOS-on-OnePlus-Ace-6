#!/system/bin/sh
###########################################################
# OnePlus Ace 6 ColorOS Auto-Brightness Diagnostic Action
# Triggered via Magisk / KernelSU / APatch Action Button
###########################################################

MODDIR="${0%/*}"
echo "=============================================="
echo " OnePlus Ace 6 ColorOS Auto-Brightness Status"
echo "=============================================="

SRC="$MODDIR/system/vendor/etc/displayconfig/display_id_4630947185118785939.xml"
[ ! -f "$SRC" ] && SRC="$MODDIR/vendor/etc/displayconfig/display_id_4630947185118785939.xml"
TARGET="/vendor/etc/displayconfig/display_id_4630947185118785939.xml"

if [ -f "$TARGET" ]; then
    TGT_SUM=$(md5sum "$TARGET" 2>/dev/null | cut -d' ' -f1)
    SRC_SUM=$(md5sum "$SRC" 2>/dev/null | cut -d' ' -f1)
    echo "[*] Target XML MD5: $TGT_SUM"
    echo "[*] Module XML MD5: $SRC_SUM"
    if [ "$TGT_SUM" = "$SRC_SUM" ]; then
        echo "[+] DisplayConfig Status: Active (Target matched module file)"
    else
        echo "[-] DisplayConfig Status: Mismatched or not mounted"
    fi
else
    echo "[-] Error: $TARGET does not exist!"
fi

echo "----------------------------------------------"
echo "[*] Watchdog Daemon Status:"
PIDFILE="/dev/watchdog_autobright.pid"
if [ -f "$PIDFILE" ]; then
    PID=$(cat "$PIDFILE" 2>/dev/null)
    if [ -n "$PID" ] && [ -d "/proc/$PID" ]; then
        echo "[+] Watchdog is RUNNING (PID: $PID)"
    else
        echo "[-] Watchdog process dead, restarting..."
        nohup /system/bin/sh "$MODDIR/watchdog.sh" >/dev/null 2>&1 &
    fi
else
    echo "[-] Watchdog not running, launching..."
    nohup /system/bin/sh "$MODDIR/watchdog.sh" >/dev/null 2>&1 &
fi

if [ -f "$MODDIR/watchdog.log" ]; then
    echo "[*] Recent Watchdog Events (last 5 lines):"
    tail -n 5 "$MODDIR/watchdog.log" 2>/dev/null
fi

echo "----------------------------------------------"
echo "[*] Live Display Diagnostics:"

AMBIENT_LUX=$(dumpsys display 2>/dev/null | grep -m 1 "mAmbientLuxValid=true" -A 10 | grep -m 1 "mAmbientLux=" | tr -d ' ')
[ -z "$AMBIENT_LUX" ] && AMBIENT_LUX=$(dumpsys display 2>/dev/null | grep -m 1 "mAmbientLux=" | tr -d ' ')
echo "    Ambient Lux  : $AMBIENT_LUX"

CURRENT_BRT=$(cmd display get-brightness 2>/dev/null)
echo "    Float Bright : $CURRENT_BRT"

if [ -f /sys/class/backlight/panel0-backlight/brightness ]; then
    HW_BL=$(cat /sys/class/backlight/panel0-backlight/brightness 2>/dev/null)
    echo "    Hardware DBV : $HW_BL (Max: 4094, Normal Max: 3515)"
fi

# If lux is 0.0 or hardware DBV <= 80, perform immediate test reset
if [ "$HW_BL" -le 80 ] 2>/dev/null; then
    echo "[!] Low backlight detected. Refreshing light sensor now..."
    settings put system screen_brightness_mode 0
    sleep 0.05
    settings put system screen_brightness_mode 1
    sleep 0.2
    NEW_DBV=$(cat /sys/class/backlight/panel0-backlight/brightness 2>/dev/null)
    echo "[+] Sensor refreshed. New Hardware DBV: $NEW_DBV"
fi

echo "=============================================="
