#!/system/bin/sh
###########################################################
# OnePlus Ace 6 ColorOS Auto-Brightness Module (boot-completed.sh)
# Executed by KernelSU / APatch at boot_completed
###########################################################

MODDIR="${0%/*}"

# Escape init cgroup
for cg in /sys/fs/cgroup/cgroup.procs /dev/cpuset/cgroup.procs /dev/stune/cgroup.procs; do
    [ -w "$cg" ] && echo $$ > "$cg" 2>/dev/null
done

# Ensure watchdog daemon is running
PIDFILE="/dev/watchdog_autobright.pid"
NEED_START=1
if [ -f "$PIDFILE" ]; then
    OLD_PID=$(cat "$PIDFILE" 2>/dev/null)
    if [ -n "$OLD_PID" ] && [ -d "/proc/$OLD_PID" ]; then
        NEED_START=0
    fi
fi

if [ "$NEED_START" = "1" ] && [ -f "$MODDIR/watchdog.sh" ]; then
    chmod 0755 "$MODDIR/watchdog.sh"
    nohup /system/bin/sh "$MODDIR/watchdog.sh" >/dev/null 2>&1 &
fi

