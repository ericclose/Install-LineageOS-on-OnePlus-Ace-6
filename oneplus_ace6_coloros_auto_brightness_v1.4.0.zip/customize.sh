###########################################################
# OnePlus Ace 6 ColorOS Auto-Brightness Module Installer
# Compatible with Magisk, KernelSU, and APatch
###########################################################

ui_print "***********************************************"
ui_print "*  OnePlus Ace 6 ColorOS Auto-Brightness v1.4.0 *"
ui_print "*     Tianma P_7 Calibration & Lux Curve      *"
ui_print "*   Pixel 10-Nit Floor & Multi-Tier Watchdog  *"
ui_print "***********************************************"

if [ "$KSU" = "true" ]; then
    ui_print "- Environment: KernelSU (v$KSU_VER, ksu_ver_code: $KSU_VER_CODE)"
elif [ "$APATCH" = "true" ]; then
    ui_print "- Environment: APatch (v$APATCH_VER)"
else
    ui_print "- Environment: Magisk ($MAGISK_VER)"
fi

DEVICE_NAME=$(getprop ro.product.device)
[ -z "$DEVICE_NAME" ] && DEVICE_NAME=$(getprop ro.build.product)
ui_print "- Detected Device: $DEVICE_NAME (API: $API, Arch: $ARCH)"

TARGET_CFG="/vendor/etc/displayconfig/display_id_4630947185118785939.xml"
if [ -f "$TARGET_CFG" ]; then
    ui_print "- Verified target display config exists:"
    ui_print "  $TARGET_CFG"
else
    ui_print "! Notice: Target display config not found in current /vendor."
    ui_print "! The module will still install and attempt to overlay/bind."
fi

ui_print "- Applying permissions and SELinux contexts..."

# Set standard permissions
set_perm_recursive "$MODPATH" 0 0 0755 0644

# Specific script permissions
[ -f "$MODPATH/post-fs-data.sh" ] && set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
[ -f "$MODPATH/service.sh" ] && set_perm "$MODPATH/service.sh" 0 0 0755
[ -f "$MODPATH/boot-completed.sh" ] && set_perm "$MODPATH/boot-completed.sh" 0 0 0755
[ -f "$MODPATH/watchdog.sh" ] && set_perm "$MODPATH/watchdog.sh" 0 0 0755
[ -f "$MODPATH/action.sh" ] && set_perm "$MODPATH/action.sh" 0 0 0755

# Ensure vendor displayconfig XML has vendor_configs_file context
DISPLAY_XML="$MODPATH/system/vendor/etc/displayconfig/display_id_4630947185118785939.xml"
if [ -f "$DISPLAY_XML" ]; then
    set_perm "$DISPLAY_XML" 0 0 0644 u:object_r:vendor_configs_file:s0
fi

ui_print "- Installation finished! Please reboot your device."
