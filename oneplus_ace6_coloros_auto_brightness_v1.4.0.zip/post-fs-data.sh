#!/system/bin/sh
###########################################################
# OnePlus Ace 6 ColorOS Auto-Brightness Module (post-fs-data)
# Runs early in boot before Zygote starts
###########################################################

MODDIR="${0%/*}"

# Find source XML file (support both system/vendor and moved vendor structures)
SRC="$MODDIR/system/vendor/etc/displayconfig/display_id_4630947185118785939.xml"
[ ! -f "$SRC" ] && SRC="$MODDIR/vendor/etc/displayconfig/display_id_4630947185118785939.xml"

TARGET="/vendor/etc/displayconfig/display_id_4630947185118785939.xml"

if [ -f "$SRC" ] && [ -f "$TARGET" ]; then
    # Ensure SELinux context is vendor_configs_file
    chcon u:object_r:vendor_configs_file:s0 "$SRC" 2>/dev/null

    # If overlayfs or magic mount didn't mount it, perform fallback bind mount
    SRC_SUM=$(md5sum "$SRC" 2>/dev/null | cut -d' ' -f1)
    TGT_SUM=$(md5sum "$TARGET" 2>/dev/null | cut -d' ' -f1)

    if [ -n "$SRC_SUM" ] && [ "$SRC_SUM" != "$TGT_SUM" ]; then
        mount -o bind "$SRC" "$TARGET" 2>/dev/null
    fi
fi
