#!/system/bin/sh
###########################################################
# OnePlus Ace 6 ColorOS Auto-Brightness Module (service.sh)
# Runs in late_start service mode after boot
###########################################################

MODDIR="${0%/*}"

# Escape init cgroup to prevent SIGKILL when ksud services exits
for cg in /sys/fs/cgroup/cgroup.procs /dev/cpuset/cgroup.procs /dev/stune/cgroup.procs; do
    [ -w "$cg" ] && echo $$ > "$cg" 2>/dev/null
done

# Perform displayconfig bind mount if needed
SRC="$MODDIR/system/vendor/etc/displayconfig/display_id_4630947185118785939.xml"
[ ! -f "$SRC" ] && SRC="$MODDIR/vendor/etc/displayconfig/display_id_4630947185118785939.xml"
TARGET="/vendor/etc/displayconfig/display_id_4630947185118785939.xml"

if [ -f "$SRC" ] && [ -f "$TARGET" ]; then
    chcon u:object_r:vendor_configs_file:s0 "$SRC" 2>/dev/null
    SRC_SUM=$(md5sum "$SRC" 2>/dev/null | cut -d' ' -f1)
    TGT_SUM=$(md5sum "$TARGET" 2>/dev/null | cut -d' ' -f1)
    if [ -n "$SRC_SUM" ] && [ "$SRC_SUM" != "$TGT_SUM" ]; then
        mount -o bind "$SRC" "$TARGET" 2>/dev/null
    fi
fi

# Launch watchdog daemon in completely detached background session
if [ -f "$MODDIR/watchdog.sh" ]; then
    chmod 0755 "$MODDIR/watchdog.sh"
    # Launch with setsid and nohup in background
    nohup /system/bin/sh "$MODDIR/watchdog.sh" >/dev/null 2>&1 &
fi
