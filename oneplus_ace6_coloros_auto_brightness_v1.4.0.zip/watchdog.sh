#!/system/bin/sh
###########################################################
# OnePlus Ace 6 ColorOS Auto-Brightness Watchdog Daemon
# v1.4.0: Pixel-grade Adaptive Zero-Dip & Multi-Tier Recovery
#
# Combines:
# 1. Instant pre-override brightness lock (blocks dip)
# 2. 600ms settling delay for Qualcomm DRM CWB tear-down
# 3. 1.2s secondary verification kick (v1.2.0 proven logic)
# 4. Robust 4s fail-safe periodic monitor without fragile dumpsys
###########################################################

MODDIR="${0%/*}"
LOGFILE="$MODDIR/watchdog.log"
PIDFILE="/dev/watchdog_autobright.pid"

# Move process to root cgroup to survive init oneshot service cgroup termination
for cg in /sys/fs/cgroup/cgroup.procs /dev/cpuset/cgroup.procs /dev/stune/cgroup.procs; do
    [ -w "$cg" ] && echo $$ > "$cg" 2>/dev/null
done

# Ensure single instance
if [ -f "$PIDFILE" ]; then
    OLD_PID=$(cat "$PIDFILE" 2>/dev/null)
    if [ -n "$OLD_PID" ] && [ -d "/proc/$OLD_PID" ] && [ "$OLD_PID" != "$$" ]; then
        exit 0
    fi
fi
echo $$ > "$PIDFILE"

log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOGFILE"
    log -t AutoBrightWatchdog "$*" 2>/dev/null
}

log_info "Auto-Brightness Watchdog v1.4.0 started (PID $$)."

# Wait for boot completion
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done
log_info "Boot completed. Initializing multi-tier monitor."

# Routine 1: Event-driven Real-Time Pre-Override Freeze & Recovery
monitor_override() {
    for cg in /sys/fs/cgroup/cgroup.procs /dev/cpuset/cgroup.procs; do
        [ -w "$cg" ] && echo $$ > "$cg" 2>/dev/null
    done

    LAST_AUTO_BRT="0.31"
    IS_IN_OVERRIDE=0

    logcat -b system -s DisplayBrightnessStrategySelector:I DisplayPowerController:I | while read -r line; do
        case "$line" in
            *"reason=override"*|"strat=OverrideBrightnessStrategy"*)
                if [ "$IS_IN_OVERRIDE" -eq 0 ]; then
                    IS_IN_OVERRIDE=1
                    case "$line" in
                        *"initBrt="*)
                            EXTRACTED=$(echo "$line" | sed -n 's/.*initBrt=\([0-9.]*\).*/\1/p')
                            if [ -n "$EXTRACTED" ] && [ "$EXTRACTED" != "NaN" ]; then
                                LAST_AUTO_BRT="$EXTRACTED"
                            fi
                            ;;
                    esac
                    log_info "Captured pre-override brightness: $LAST_AUTO_BRT"
                fi
                ;;

            *"Changing the DisplayBrightnessStrategy from OverrideBrightnessStrategy to"*)
                IS_IN_OVERRIDE=0
                TARGET_BRT="${LAST_AUTO_BRT:-0.31}"
                log_info "Override exit detected. Locking pre-override brightness at $TARGET_BRT (blocking dip)..."

                AUTO_MODE=$(settings get system screen_brightness_mode 2>/dev/null)
                if [ "$AUTO_MODE" = "1" ]; then
                    # Tier 1: Immediately lock brightness at pre-override level to block the 0.0 lux dip
                    settings put system screen_brightness_mode 0
                    cmd display set-brightness "$TARGET_BRT" 2>/dev/null

                    # Tier 2: Wait 600ms for window dismiss animation & Qualcomm SDM DRM CWB tear-down
                    sleep 0.6

                    # Re-enable auto-brightness with clean surface & sensor state
                    settings put system screen_brightness_mode 1
                    log_info "Auto-brightness re-enabled after 600ms CWB stabilization."

                    # Tier 3 (Secondary insurance from v1.2.0):
                    # Check after another 600ms (1.2s total) if backlight fell into low range
                    sleep 0.6
                    CURR_DBV=$(cat /sys/class/backlight/panel0-backlight/brightness 2>/dev/null)
                    if [ -n "$CURR_DBV" ] && [ "$CURR_DBV" -gt 0 ] && [ "$CURR_DBV" -le 150 ]; then
                        log_info "Tier 3 kick: DBV is $CURR_DBV after 1.2s. Resetting light sensor to unfreeze..."
                        settings put system screen_brightness_mode 0
                        sleep 0.05
                        settings put system screen_brightness_mode 1
                        log_info "Tier 3 light sensor reset complete."
                    fi
                fi
                ;;
        esac
    done
}

# Routine 2: Periodic Fail-Safe Monitor (Tier 4)
# Robust sysfs-based monitor: if screen is powered on (DBV > 0) but stuck in low DBV (<= 150) for 4s
monitor_periodic() {
    for cg in /sys/fs/cgroup/cgroup.procs /dev/cpuset/cgroup.procs; do
        [ -w "$cg" ] && echo $$ > "$cg" 2>/dev/null
    done

    STUCK_COUNT=0
    while true; do
        sleep 2

        CURR_DBV=$(cat /sys/class/backlight/panel0-backlight/brightness 2>/dev/null)
        # DBV > 0 means screen is physically powered on
        if [ -n "$CURR_DBV" ] && [ "$CURR_DBV" -gt 0 ] && [ "$CURR_DBV" -le 150 ]; then
            AUTO_MODE=$(settings get system screen_brightness_mode 2>/dev/null)
            if [ "$AUTO_MODE" = "1" ]; then
                STUCK_COUNT=$((STUCK_COUNT + 1))
                # If stuck for 2 consecutive cycles (4s)
                if [ "$STUCK_COUNT" -ge 2 ]; then
                    log_info "Tier 4 Fail-Safe: Screen active but stuck at DBV=$CURR_DBV for 4s. Resetting sensor..."
                    settings put system screen_brightness_mode 0
                    sleep 0.05
                    settings put system screen_brightness_mode 1
                    STUCK_COUNT=0
                fi
            else
                STUCK_COUNT=0
            fi
        else
            STUCK_COUNT=0
        fi
    done
}

# Launch routines in background
monitor_override &
monitor_periodic &

# Wait for children
wait
